import java.util.*;

public class ThirdRatings {
    private ArrayList<Rater> myRaters;

    public ThirdRatings() {
        this("ratings.csv");
    }

    public ThirdRatings(String ratingsfile) {
        FirstRatings fr = new FirstRatings();
        myRaters = fr.loadRaters(ratingsfile);
    }

    public int getRaterSize() {
        return myRaters.size();
    }

    private double getAverageByID(String movieID, int minimalRaters) {
        int count = 0;
        double total = 0.0;
        for (Rater r : myRaters) {
            if (r.hasRating(movieID)) {
                count++;
                total += r.getRating(movieID);
            }
        }
        if (count >= minimalRaters) {
            return total / count;
        }
        return 0.0;
    }

    public ArrayList<Rating> getAverageRatings(int minimalRaters) {
        ArrayList<Rating> result = new ArrayList<>();
        ArrayList<String> movies = MovieDatabase.filterBy(new TrueFilter());

        for (String movieID : movies) {
            double avg = getAverageByID(movieID, minimalRaters);
            if (avg > 0.0) {
                result.add(new Rating(movieID, avg));
            }
        }

        return result;
    }

    public ArrayList<Rating> getAverageRatingsByFilter(int minimalRaters, Filter filterCriteria) {
        ArrayList<Rating> result = new ArrayList<>();
        ArrayList<String> movies = MovieDatabase.filterBy(filterCriteria);

        for (String movieID : movies) {
            double avg = getAverageByID(movieID, minimalRaters);
            if (avg > 0.0) {
                result.add(new Rating(movieID, avg));
            }
        }

        return result;
    }
}
