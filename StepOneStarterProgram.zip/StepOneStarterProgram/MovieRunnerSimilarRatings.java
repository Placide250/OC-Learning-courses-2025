import java.util.*;

public class MovieRunnerSimilarRatings {

    public void runQuestion6() {
        RaterDatabase.initialize("ratings.csv");
        MovieDatabase.initialize("ratedmoviesfull.csv");

        FourthRatings fr = new FourthRatings();
        ArrayList<Rating> ratings = fr.getSimilarRatings("337", 10, 3);

        if (ratings.size() > 0) {
            Rating top = ratings.get(0);
            System.out.println(top.getValue() + " " + MovieDatabase.getTitle(top.getItem()));
        } else {
            System.out.println("No similar ratings found.");
        }
    }

    public void runQuestion7() {
        RaterDatabase.initialize("ratings.csv");
        MovieDatabase.initialize("ratedmoviesfull.csv");

        FourthRatings fr = new FourthRatings();
        GenreFilter gf = new GenreFilter("Mystery");

        ArrayList<Rating> ratings = fr.getSimilarRatingsByFilter("964", 20, 5, gf);

        if (ratings.size() > 0) {
            Rating top = ratings.get(0);
            System.out.println(top.getValue() + " " + MovieDatabase.getTitle(top.getItem()));
        } else {
            System.out.println("No similar ratings found.");
        }
    }

    public void runQuestion8() {
        RaterDatabase.initialize("ratings.csv");
        MovieDatabase.initialize("ratedmoviesfull.csv");

        FourthRatings fr = new FourthRatings();
        ArrayList<Rating> ratings = fr.getSimilarRatings("71", 20, 5);

        if (ratings.size() > 0) {
            Rating top = ratings.get(0);
            System.out.println(top.getValue() + " " + MovieDatabase.getTitle(top.getItem()));
        } else {
            System.out.println("No similar ratings found.");
        }
    }

    public void runQuestion9() {
        RaterDatabase.initialize("ratings.csv");
        MovieDatabase.initialize("ratedmoviesfull.csv");

        FourthRatings fr = new FourthRatings();
        DirectorsFilter df = new DirectorsFilter("Clint Eastwood,J.J. Abrams,Alfred Hitchcock,Sydney Pollack,David Cronenberg,Oliver Stone,Mike Leigh");

        ArrayList<Rating> ratings = fr.getSimilarRatingsByFilter("120", 10, 2, df);

        if (ratings.size() > 0) {
            Rating top = ratings.get(0);
            System.out.println(top.getValue() + " " + MovieDatabase.getTitle(top.getItem()));
        } else {
            System.out.println("No similar ratings found.");
        }
    }

    public void runQuestion10() {
        RaterDatabase.initialize("ratings.csv");
        MovieDatabase.initialize("ratedmoviesfull.csv");

        FourthRatings fr = new FourthRatings();
        AllFilters af = new AllFilters();
        af.addFilter(new GenreFilter("Drama"));
        af.addFilter(new MinutesFilter(80, 160));

        ArrayList<Rating> ratings = fr.getSimilarRatingsByFilter("168", 10, 3, af);

        if (ratings.size() > 0) {
            Rating top = ratings.get(0);
            System.out.println(top.getValue() + " " + MovieDatabase.getTitle(top.getItem()));
        } else {
            System.out.println("No similar ratings found.");
        }
    }

    public void runQuestion11() {
        RaterDatabase.initialize("ratings.csv");
        MovieDatabase.initialize("ratedmoviesfull.csv");

        FourthRatings fr = new FourthRatings();
        AllFilters af = new AllFilters();
        af.addFilter(new YearAfterFilter(1975));
        af.addFilter(new MinutesFilter(70, 200));

        ArrayList<Rating> ratings = fr.getSimilarRatingsByFilter("314", 10, 5, af);

        if (ratings.size() > 0) {
            Rating top = ratings.get(0);
            System.out.println(top.getValue() + " " + MovieDatabase.getTitle(top.getItem()));
        } else {
            System.out.println("No similar ratings found.");
        }
    }
}
