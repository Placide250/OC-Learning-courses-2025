public class DirectorsFilter implements Filter {
    private String[] myDirectors;

    public DirectorsFilter(String directors) {
        myDirectors = directors.split(",");
    }

    public boolean satisfies(String id) {
        String movieDirectors = MovieDatabase.getDirector(id);
        for (String director : myDirectors) {
            if (movieDirectors.contains(director.trim())) {
                return true;
            }
        }
        return false;
    }
}
