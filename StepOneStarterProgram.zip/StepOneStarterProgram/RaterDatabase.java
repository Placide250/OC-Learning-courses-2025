import java.util.*;
import edu.duke.*;
import org.apache.commons.csv.*;

public class RaterDatabase {
    private static HashMap<String, Rater> raters;

    public static void initialize(String filename) {
        if (raters == null) {
            raters = new HashMap<>();
            addRatings(filename);
        }
    }

    private static void addRatings(String filename) {
        FileResource fr = new FileResource(filename);
        for (CSVRecord rec : fr.getCSVParser()) {
            String raterID = rec.get("rater_id");
            String movieID = rec.get("movie_id");
            double rating = Double.parseDouble(rec.get("rating"));
            if (!raters.containsKey(raterID)) {
                raters.put(raterID, new Rater(raterID));
            }
            raters.get(raterID).addRating(movieID, rating);
        }
    }

    public static Rater getRater(String id) {
        return raters.get(id);
    }

    public static ArrayList<Rater> getRaters() {
        return new ArrayList<>(raters.values());
    }

    public static int size() {
        return raters.size();
    }
}
