import java.util.*;

public class FourthRatings {
    public double dotProduct(Rater me, Rater r) {
        double sum = 0.0;
        for (String item : me.getItemsRated()) {
            if (r.hasRating(item)) {
                sum += (me.getRating(item) - 5.0) * (r.getRating(item) - 5.0);
            }
        }
        return sum;
    }

    public ArrayList<Rating> getSimilarities(String id) {
        ArrayList<Rating> similarities = new ArrayList<>();
        Rater me = RaterDatabase.getRater(id);

        for (Rater other : RaterDatabase.getRaters()) {
            if (!other.getID().equals(id)) {
                double sim = dotProduct(me, other);
                if (sim > 0) {
                    similarities.add(new Rating(other.getID(), sim));
                }
            }
        }

        Collections.sort(similarities, Collections.reverseOrder());
        return similarities;
    }

    public ArrayList<Rating> getSimilarRatings(String id, int numSimilarRaters, int minimalRaters) {
        return getSimilarRatingsByFilter(id, numSimilarRaters, minimalRaters, new TrueFilter());
    }

    public ArrayList<Rating> getSimilarRatingsByFilter(String id, int numSimilarRaters, int minimalRaters, Filter filterCriteria) {
        ArrayList<Rating> similarRaters = getSimilarities(id);
        ArrayList<Rating> ratings = new ArrayList<>();

        ArrayList<String> movies = MovieDatabase.filterBy(filterCriteria);
        for (String movieID : movies) {
            double total = 0;
            int count = 0;

            for (int i = 0; i < numSimilarRaters && i < similarRaters.size(); i++) {
                Rating simRating = similarRaters.get(i);
                Rater r = RaterDatabase.getRater(simRating.getItem());
                if (r.hasRating(movieID)) {
                    count++;
                    total += simRating.getValue() * r.getRating(movieID);
                }
            }

            if (count >= minimalRaters) {
                ratings.add(new Rating(movieID, total / count));
            }
        }

        Collections.sort(ratings, Collections.reverseOrder());
        return ratings;
    }
}
