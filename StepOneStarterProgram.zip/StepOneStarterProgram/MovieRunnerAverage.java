import java.util.*;

public class MovieRunnerAverage {

    public void answerQuestions() {
        SecondRatings sr = new SecondRatings("data/ratedmoviesfull.csv", "data/ratings.csv");

        // Question 8: How many movies have 50 or more ratings?
        ArrayList<Rating> ratings50 = sr.getAverageRatings(50);
        System.out.println("Number of movies with at least 50 ratings: " + ratings50.size());

        // Questions 5, 6, 7: Ratings for specific movies
        printAverageForMovie(sr, "The Maze Runner");
        printAverageForMovie(sr, "Moneyball");
        printAverageForMovie(sr, "Vacation");

        // Question 9: Lowest rated movie with at least 20 ratings
        ArrayList<Rating> ratings20 = sr.getAverageRatings(20);
        if (ratings20.isEmpty()) {
            System.out.println("No movies with at least 20 ratings.");
            return;
        }
        Rating lowest = ratings20.get(0);
        for (Rating r : ratings20) {
            if (r.getValue() < lowest.getValue()) {
                lowest = r;
            }
        }
        System.out.println("Lowest rated movie with at least 20 ratings:");
        System.out.println(sr.getTitle(lowest.getItem()) + " with average rating: " + String.format("%.4f", lowest.getValue()));
    }

    private void printAverageForMovie(SecondRatings sr, String title) {
        String id = sr.getID(title);
        if (id.equals("NO SUCH TITLE")) {
            System.out.println("Movie \"" + title + "\" not found.");
            return;
        }
        double avgRating = sr.getAverageByID(id, 1);  // minimalRaters=1
        System.out.println("Average rating for \"" + title + "\": " + String.format("%.4f", avgRating));
    }

    public static void main(String[] args) {
        MovieRunnerAverage runner = new MovieRunnerAverage();
        runner.answerQuestions();
    }
}
