import java.util.*;

public class MovieRunnerWithFilters {
    public void printAverageRatings() {
        ThirdRatings tr = new ThirdRatings("ratings.csv");
        MovieDatabase.initialize("ratedmoviesfull.csv");

        int minimalRaters = 35;
        ArrayList<Rating> ratings = tr.getAverageRatings(minimalRaters);

        System.out.println("Found " + ratings.size() + " movies");
        for (Rating r : ratings) {
            System.out.println(r.getValue() + " " + MovieDatabase.getTitle(r.getItem()));
        }
    }

    public void printAverageRatingsByYearAfter() {
        ThirdRatings tr = new ThirdRatings("ratings.csv");
        MovieDatabase.initialize("ratedmoviesfull.csv");

        int minimalRaters = 20;
        YearAfterFilter yaf = new YearAfterFilter(2000);
        ArrayList<Rating> ratings = tr.getAverageRatingsByFilter(minimalRaters, yaf);

        System.out.println("Found " + ratings.size() + " movies");
        for (Rating r : ratings) {
            System.out.println(r.getValue() + " " + MovieDatabase.getYear(r.getItem()) + " " + MovieDatabase.getTitle(r.getItem()));
        }
    }

    public void printAverageRatingsByGenre() {
        ThirdRatings tr = new ThirdRatings("ratings.csv");
        MovieDatabase.initialize("ratedmoviesfull.csv");

        int minimalRaters = 20;
        GenreFilter gf = new GenreFilter("Comedy");
        ArrayList<Rating> ratings = tr.getAverageRatingsByFilter(minimalRaters, gf);

        System.out.println("Found " + ratings.size() + " movies");
        for (Rating r : ratings) {
            System.out.println(r.getValue() + " " + MovieDatabase.getTitle(r.getItem()));
        }
    }

    public void printAverageRatingsByMinutes() {
        ThirdRatings tr = new ThirdRatings("ratings.csv");
        MovieDatabase.initialize("ratedmoviesfull.csv");

        int minimalRaters = 5;
        MinutesFilter mf = new MinutesFilter(105, 135);
        ArrayList<Rating> ratings = tr.getAverageRatingsByFilter(minimalRaters, mf);

        System.out.println("Found " + ratings.size() + " movies");
        for (Rating r : ratings) {
            System.out.println(r.getValue() + " Time: " + MovieDatabase.getMinutes(r.getItem()) + " " + MovieDatabase.getTitle(r.getItem()));
        }
    }

    public void printAverageRatingsByDirectors() {
        ThirdRatings tr = new ThirdRatings("ratings.csv");
        MovieDatabase.initialize("ratedmoviesfull.csv");

        int minimalRaters = 4;
        String directors = "Clint Eastwood,Joel Coen,Martin Scorsese,Roman Polanski,Nora Ephron,Ridley Scott,Sydney Pollack";
        DirectorsFilter df = new DirectorsFilter(directors);
        ArrayList<Rating> ratings = tr.getAverageRatingsByFilter(minimalRaters, df);

        System.out.println("Found " + ratings.size() + " movies");
        for (Rating r : ratings) {
            System.out.println(r.getValue() + " " + MovieDatabase.getTitle(r.getItem()));
        }
    }

    public void printAverageRatingsByYearAfterAndGenre() {
        ThirdRatings tr = new ThirdRatings("ratings.csv");
        MovieDatabase.initialize("ratedmoviesfull.csv");

        int minimalRaters = 8;
        AllFilters af = new AllFilters();
        af.addFilter(new YearAfterFilter(1990));
        af.addFilter(new GenreFilter("Drama"));

        ArrayList<Rating> ratings = tr.getAverageRatingsByFilter(minimalRaters, af);

        System.out.println("Found " + ratings.size() + " movies");
        for (Rating r : ratings) {
            System.out.println(r.getValue() + " " + MovieDatabase.getYear(r.getItem()) + " " + MovieDatabase.getTitle(r.getItem()));
        }
    }

    public void printAverageRatingsByDirectorsAndMinutes() {
        ThirdRatings tr = new ThirdRatings("ratings.csv");
        MovieDatabase.initialize("ratedmoviesfull.csv");

        int minimalRaters = 3;
        AllFilters af = new AllFilters();
        af.addFilter(new MinutesFilter(90, 180));
        af.addFilter(new DirectorsFilter("Clint Eastwood,Joel Coen,Tim Burton,Ron Howard,Nora Ephron,Sydney Pollack"));

        ArrayList<Rating> ratings = tr.getAverageRatingsByFilter(minimalRaters, af);

        System.out.println("Found " + ratings.size() + " movies");
        for (Rating r : ratings) {
            System.out.println(r.getValue() + " Time: " + MovieDatabase.getMinutes(r.getItem()) + " " + MovieDatabase.getTitle(r.getItem()));
        }
    }

public class Tester {
    public static void main(String[] args) {
        MovieRunnerWithFilters runner = new MovieRunnerWithFilters();

        runner.printAverageRatings();                     // Question 4
        runner.printAverageRatingsByYearAfter();          // Question 5
        runner.printAverageRatingsByGenre();              // Question 6
        runner.printAverageRatingsByMinutes();            // Question 7
        runner.printAverageRatingsByDirectors();          // Question 8
        runner.printAverageRatingsByYearAfterAndGenre();  // Question 9
        runner.printAverageRatingsByDirectorsAndMinutes();// Question 10
    }
}
}