public class TrueFilter implements Filter {
    public boolean satisfies(String id) {
        return true;
    }
}
