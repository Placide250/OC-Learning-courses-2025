import java.io.*;
import java.util.*;
import org.apache.commons.csv.*;
import edu.duke.*;

public class FirstRatings {
    public ArrayList<Movie> loadMovies(String filename) {
        ArrayList<Movie> movies = new ArrayList<>();
        FileResource fr = new FileResource(filename);
        CSVParser parser = fr.getCSVParser();

        for (CSVRecord record : parser) {
            String id = record.get("id");
            String title = record.get("title");
            String year = record.get("year");
            String country = record.get("country");
            String genre = record.get("genre");
            String director = record.get("director");
            String minutes = record.get("minutes");
            String poster = record.get("poster");

            Movie movie = new Movie(id, title, year, genre, director, country, poster, Integer.parseInt(minutes));
            movies.add(movie);
        }
        return movies;
    }

    public ArrayList<Rater> loadRaters(String filename) {
        ArrayList<Rater> raters = new ArrayList<>();
        HashMap<String, Rater> raterMap = new HashMap<>();

        FileResource fr = new FileResource(filename);
        CSVParser parser = fr.getCSVParser();

        for (CSVRecord record : parser) {
            String raterID = record.get("rater_id");
            String movieID = record.get("movie_id");
            double rating = Double.parseDouble(record.get("rating"));

            Rater rater = raterMap.getOrDefault(raterID, new Rater(raterID));
            rater.addRating(movieID, rating);
            raterMap.put(raterID, rater);
        }

        raters.addAll(raterMap.values());
        return raters;
    }
}
