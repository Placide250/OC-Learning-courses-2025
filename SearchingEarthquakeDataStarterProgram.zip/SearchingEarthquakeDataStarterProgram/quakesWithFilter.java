import java.util.*;
import edu.duke.*;


public void quakesWithFilter() {
    EarthQuakeParser parser = new EarthQuakeParser();
    String source = "nov20quakedata.atom"; // Use the full data file here
    ArrayList<QuakeEntry> list = parser.read(source);

    System.out.println("Read data for " + list.size() + " quakes");

    // Location of Tokyo
    Location tokyo = new Location(35.42, 139.43);
    DistanceFilter distFilter = new DistanceFilter(tokyo, 10000000); // 10 million meters
    ArrayList<QuakeEntry> distFiltered = filter(list, distFilter);

    // Filter earthquakes whose title ends with "Japan"
    PhraseFilter phraseFilter = new PhraseFilter("end", "Japan");
    ArrayList<QuakeEntry> finalFiltered = filter(distFiltered, phraseFilter);

    // Print all matching earthquakes
    for (QuakeEntry qe : finalFiltered) {
        System.out.println(qe);
    }

    // Print the count
    System.out.println("Found " + finalFiltered.size() + " earthquakes matching this filter.");
}
public static void main(String[] args) {
    EarthQuakeClient2 client = new EarthQuakeClient2();
    client.quakesWithFilter();
}