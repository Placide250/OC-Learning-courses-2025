import java.util.*;
import edu.duke.*;

public class EarthQuakeDepthFilter {

    // Filters quakes by depth between minDepth and maxDepth (exclusive)
    public ArrayList<QuakeEntry> quakesOfDepth(ArrayList<QuakeEntry> quakes, double minDepth, double maxDepth) {
        ArrayList<QuakeEntry> filtered = new ArrayList<>();
        for (QuakeEntry qe : quakes) {
            double depth = qe.getDepth();
            if (depth > minDepth && depth < maxDepth) {
                filtered.add(qe);
            }
        }
        return filtered;
    }

    public void testQuakesOfDepth() {
        EarthQuakeParser parser = new EarthQuakeParser();
        String source = "nov20quakedata.atom";  // Full dataset file
        ArrayList<QuakeEntry> list = parser.read(source);

        if (list == null) {
            System.out.println("No data read - list is null");
            return;
        }

        System.out.println("Read data for " + list.size() + " quakes");

        double minDepth = -10000.0;
        double maxDepth = -8000.0;

        ArrayList<QuakeEntry> depthFiltered = quakesOfDepth(list, minDepth, maxDepth);

        System.out.println("Earthquakes with depth between " + minDepth + " and " + maxDepth + ":");
        for (QuakeEntry qe : depthFiltered) {
            System.out.println(qe);
        }

        System.out.println("Found " + depthFiltered.size() + " earthquakes matching depth criteria.");
    }

    public static void main(String[] args) {
        EarthQuakeDepthFilter eqdf = new EarthQuakeDepthFilter();
        eqdf.testQuakesOfDepth();
    }
}
