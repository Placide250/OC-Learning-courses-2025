import java.util.*;
import edu.duke.*;

public class LargestQuakesFinder {

    // Returns a list of the largest quakes (up to numLargest entries)
    public ArrayList<QuakeEntry> findLargestQuakes(ArrayList<QuakeEntry> quakeData, int numLargest) {
        ArrayList<QuakeEntry> copy = new ArrayList<>(quakeData);
        ArrayList<QuakeEntry> result = new ArrayList<>();

        for (int i = 0; i < numLargest; i++) {
            int maxIndex = indexOfLargest(copy);
            result.add(copy.get(maxIndex));
            copy.remove(maxIndex);
        }

        return result;
    }

    // Returns the index of the largest magnitude quake in the list
    private int indexOfLargest(ArrayList<QuakeEntry> quakeData) {
        int maxIndex = 0;
        for (int i = 1; i < quakeData.size(); i++) {
            if (quakeData.get(i).getMagnitude() > quakeData.get(maxIndex).getMagnitude()) {
                maxIndex = i;
            }
        }
        return maxIndex;
    }

    public void testFindLargestQuakes() {
        EarthQuakeParser parser = new EarthQuakeParser();
        String source = "nov20quakedata.atom"; // File with 1518 quakes
        ArrayList<QuakeEntry> list = parser.read(source);

        if (list == null) {
            System.out.println("No data read - list is null");
            return;
        }

        System.out.println("Read data for " + list.size() + " quakes");

        int numToFind = 3;
        ArrayList<QuakeEntry> largest = findLargestQuakes(list, numToFind);

        System.out.println("Top " + numToFind + " earthquakes by magnitude:");
        for (QuakeEntry qe : largest) {
            System.out.println(qe);
        }

        if (largest.size() >= 3) {
            double thirdMagnitude = largest.get(2).getMagnitude();
            System.out.printf("Magnitude of the third largest earthquake: %.2f\n", thirdMagnitude);
        } else {
            System.out.println("Not enough data to find the third largest earthquake.");
        }
    }

    public static void main(String[] args) {
        LargestQuakesFinder finder = new LargestQuakesFinder();
        finder.testFindLargestQuakes();
    }
}
