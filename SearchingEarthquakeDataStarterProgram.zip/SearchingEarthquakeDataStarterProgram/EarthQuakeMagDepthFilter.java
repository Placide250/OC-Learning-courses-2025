import java.util.*;
import edu.duke.*;

public class EarthQuakeMagDepthFilter {

    // Filters quakes by magnitude and depth range
    public ArrayList<QuakeEntry> quakesWithFilter(ArrayList<QuakeEntry> quakeData, 
                                                  double minMag, double maxMag,
                                                  double minDepth, double maxDepth) {
        ArrayList<QuakeEntry> filtered = new ArrayList<>();
        for (QuakeEntry qe : quakeData) {
            double mag = qe.getMagnitude();
            double depth = qe.getDepth();

            if (mag >= minMag && mag <= maxMag && depth >= minDepth && depth <= maxDepth) {
                filtered.add(qe);
            }
        }
        return filtered;
    }

    public void testMagDepthFilter() {
        EarthQuakeParser parser = new EarthQuakeParser();
        String source = "nov20quakedata.atom"; // Full dataset
        ArrayList<QuakeEntry> quakeList = parser.read(source);

        if (quakeList == null || quakeList.isEmpty()) {
            System.out.println("No earthquake data found.");
            return;
        }

        System.out.println("Read data for " + quakeList.size() + " quakes");

        double minMag = 4.0;
        double maxMag = 5.0;
        double minDepth = -35000.0;
        double maxDepth = -12000.0;

        ArrayList<QuakeEntry> filtered = quakesWithFilter(quakeList, minMag, maxMag, minDepth, maxDepth);

        System.out.println("Earthquakes with magnitude between 4.0–5.0 and depth -35000 to -12000:");
        for (QuakeEntry qe : filtered) {
            System.out.println(qe);
        }

        System.out.println("Found " + filtered.size() + " earthquakes matching both filters.");
    }

    public static void main(String[] args) {
        EarthQuakeMagDepthFilter filterTest = new EarthQuakeMagDepthFilter();
        filterTest.testMagDepthFilter();
    }
}
