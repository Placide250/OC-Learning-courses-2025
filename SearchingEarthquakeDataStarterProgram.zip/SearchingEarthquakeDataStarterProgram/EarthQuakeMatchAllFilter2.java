import java.util.*;
import edu.duke.*;

public class EarthQuakeMatchAllFilter2 {

    // Filters quakes based on magnitude, distance, and title substring
    public ArrayList<QuakeEntry> matchAllFilter(ArrayList<QuakeEntry> quakeData,
                                                double minMag, double maxMag,
                                                Location location, double maxDistance,
                                                String phrase) {
        ArrayList<QuakeEntry> filtered = new ArrayList<>();
        for (QuakeEntry qe : quakeData) {
            double mag = qe.getMagnitude();
            double distance = qe.getLocation().distanceTo(location);
            String info = qe.getInfo();

            if (mag >= minMag && mag <= maxMag &&
                distance < maxDistance &&
                info.contains(phrase)) {
                filtered.add(qe);
            }
        }
        return filtered;
    }

    public void testMatchAllFilter2() {
        EarthQuakeParser parser = new EarthQuakeParser(); // (Updated 1/12/16 version)
        String source = "nov20quakedata.atom"; // Full dataset with 1518 quakes
        ArrayList<QuakeEntry> quakeList = parser.read(source);

        if (quakeList == null || quakeList.isEmpty()) {
            System.out.println("No data found or file could not be read.");
            return;
        }

        System.out.println("Read data for " + quakeList.size() + " earthquakes.");

        // Filter criteria
        double minMag = 0.0;
        double maxMag = 3.0;
        Location tulsa = new Location(36.1314, -95.9372);
        double maxDistance = 10000000; // in meters
        String phrase = "Ca";

        ArrayList<QuakeEntry> filtered = matchAllFilter(quakeList, minMag, maxMag, tulsa, maxDistance, phrase);

        System.out.println("Earthquakes with:");
        System.out.println("- Magnitude between " + minMag + " and " + maxMag);
        System.out.println("- Distance from Tulsa, OK < " + maxDistance + " meters");
        System.out.println("- Title containing \"" + phrase + "\":");

        for (QuakeEntry qe : filtered) {
            System.out.println(qe);
        }

        System.out.println("Found " + filtered.size() + " earthquakes matching all three criteria.");
    }

    public static void main(String[] args) {
        EarthQuakeMatchAllFilter2 matcher = new EarthQuakeMatchAllFilter2();
        matcher.testMatchAllFilter2();
    }
}
