import java.util.*;
import edu.duke.*;

public class EarthQuakeMatchAllFilter {

    // Filters quakes based on 3 criteria: magnitude, depth, and phrase
    public ArrayList<QuakeEntry> matchAllFilter(ArrayList<QuakeEntry> quakeData,
                                                double minMag, double maxMag,
                                                double minDepth, double maxDepth,
                                                String phrase) {
        ArrayList<QuakeEntry> filtered = new ArrayList<>();
        for (QuakeEntry qe : quakeData) {
            double mag = qe.getMagnitude();
            double depth = qe.getDepth();
            String info = qe.getInfo().toLowerCase();

            if (mag >= minMag && mag <= maxMag &&
                depth >= minDepth && depth <= maxDepth &&
                info.contains(phrase.toLowerCase())) {
                filtered.add(qe);
            }
        }
        return filtered;
    }

    public void testMatchAllFilter() {
        EarthQuakeParser parser = new EarthQuakeParser(); // Make sure you're using the updated version (1/12/16)
        String source = "nov20quakedata.atom"; // Full dataset
        ArrayList<QuakeEntry> quakeList = parser.read(source);

        if (quakeList == null || quakeList.isEmpty()) {
            System.out.println("No data found or file could not be read.");
            return;
        }

        System.out.println("Read data for " + quakeList.size() + " earthquakes.");

        double minMag = 0.0;
        double maxMag = 2.0;
        double minDepth = -100000.0;
        double maxDepth = -10000.0;
        String phrase = "a";

        ArrayList<QuakeEntry> filtered = matchAllFilter(quakeList, minMag, maxMag, minDepth, maxDepth, phrase);

        System.out.println("Earthquakes with:");
        System.out.println("- Magnitude between " + minMag + " and " + maxMag);
        System.out.println("- Depth between " + minDepth + " and " + maxDepth);
        System.out.println("- Title containing the letter \"" + phrase + "\":");

        for (QuakeEntry qe : filtered) {
            System.out.println(qe);
        }

        System.out.println("Found " + filtered.size() + " earthquakes matching all three criteria.");
    }

    public static void main(String[] args) {
        EarthQuakeMatchAllFilter matcher = new EarthQuakeMatchAllFilter();
        matcher.testMatchAllFilter();
    }
}
