import java.util.*;
import edu.duke.*;

public class EarthQuakePhraseFilterEnd {

    // Filters quakes whose title contains the phrase at the specified location ("start", "end", or "any")
    public ArrayList<QuakeEntry> quakesByPhrase(ArrayList<QuakeEntry> quakes, String where, String phrase) {
        ArrayList<QuakeEntry> filtered = new ArrayList<>();
        for (QuakeEntry qe : quakes) {
            String info = qe.getInfo().toLowerCase();
            String phraseLower = phrase.toLowerCase();

            if (where.equals("start") && info.startsWith(phraseLower)) {
                filtered.add(qe);
            } else if (where.equals("end") && info.endsWith(phraseLower)) {
                filtered.add(qe);
            } else if (where.equals("any") && info.contains(phraseLower)) {
                filtered.add(qe);
            }
        }
        return filtered;
    }

    public void testQuakesByPhrase() {
        EarthQuakeParser parser = new EarthQuakeParser();
        String source = "nov20quakedata.atom"; // Full dataset
        ArrayList<QuakeEntry> list = parser.read(source);

        if (list == null) {
            System.out.println("No data read - list is null");
            return;
        }

        System.out.println("Read data for " + list.size() + " quakes");

        String phrase = "California";
        String where = "end";

        ArrayList<QuakeEntry> filtered = quakesByPhrase(list, where, phrase);

        System.out.println("Earthquakes with phrase \"" + phrase + "\" at the " + where + " of the title:");
        for (QuakeEntry qe : filtered) {
            System.out.println(qe);
        }

        System.out.println("Found " + filtered.size() + " earthquakes matching this phrase criteria.");
    }

    public static void main(String[] args) {
        EarthQuakePhraseFilterEnd eqpf = new EarthQuakePhraseFilterEnd();
        eqpf.testQuakesByPhrase();
    }
}
