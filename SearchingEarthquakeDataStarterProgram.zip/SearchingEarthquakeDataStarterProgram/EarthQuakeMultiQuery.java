import java.util.*;
import edu.duke.*;

public class EarthQuakeMultiQuery {

    private ArrayList<QuakeEntry> quakeList;

    public EarthQuakeMultiQuery() {
        EarthQuakeParser parser = new EarthQuakeParser();
        String source = "nov20quakedata.atom";
        quakeList = parser.read(source);
        System.out.println("Loaded " + quakeList.size() + " earthquake entries.");
    }

    public void runAllQueries() {
        query1();
        query2();
        query3();
        query4();
        query5();
        query6();
        query7();
        query8();
        query9();
        query10();
        query11();
    }

    // Question 1: Depth between -12000 and -10000 (exclusive)
    public void query1() {
        int count = 0;
        for (QuakeEntry qe : quakeList) {
            double d = qe.getDepth();
            if (d > -12000 && d < -10000) count++;
        }
        System.out.println("Q1: Earthquakes with depth between -12000.0 and -10000.0 (exclusive): " + count);
    }

    // Question 2: Depth between -4000 and -2000 (exclusive)
    public void query2() {
        int count = 0;
        for (QuakeEntry qe : quakeList) {
            double d = qe.getDepth();
            if (d > -4000 && d < -2000) count++;
        }
        System.out.println("Q2: Earthquakes with depth between -4000.0 and -2000.0 (exclusive): " + count);
    }

    // Question 3: Title starts with "Quarry Blast"
    public void query3() {
        int count = 0;
        for (QuakeEntry qe : quakeList) {
            if (qe.getInfo().startsWith("Quarry Blast")) count++;
        }
        System.out.println("Q3: Earthquakes starting with 'Quarry Blast': " + count);
    }

    // Question 4: Title ends with "Alaska"
    public void query4() {
        int count = 0;
        for (QuakeEntry qe : quakeList) {
            if (qe.getInfo().endsWith("Alaska")) count++;
        }
        System.out.println("Q4: Earthquakes ending with 'Alaska': " + count);
    }

    // Question 5: Title contains "Can"
    public void query5() {
        int count = 0;
        for (QuakeEntry qe : quakeList) {
            if (qe.getInfo().contains("Can")) count++;
        }
        System.out.println("Q5: Earthquakes containing 'Can': " + count);
    }

    // Question 6: 20th largest magnitude
    public void query6() {
        ArrayList<QuakeEntry> sorted = new ArrayList<>(quakeList);
        sorted.sort((a, b) -> Double.compare(b.getMagnitude(), a.getMagnitude()));
        double mag20 = sorted.get(19).getMagnitude();
        System.out.printf("Q6: Magnitude of 20th largest earthquake: %.2f%n", mag20);
    }

    // Question 7: Country of 50th largest quake (assume country is last part after comma)
    public void query7() {
        ArrayList<QuakeEntry> sorted = new ArrayList<>(quakeList);
        sorted.sort((a, b) -> Double.compare(b.getMagnitude(), a.getMagnitude()));
        String title = sorted.get(49).getInfo();
        String[] parts = title.split(",");
        String country = parts.length > 1 ? parts[parts.length - 1].trim() : "Unknown";
        System.out.println("Q7: Country of 50th largest earthquake: " + country);
    }

    // Question 8: Within 1,000 km of Denver and title ends with 'a'
    public void query8() {
        Location denver = new Location(39.7392, -104.9903);
        int count = 0;
        for (QuakeEntry qe : quakeList) {
            if (qe.getLocation().distanceTo(denver) < 1000000 && qe.getInfo().endsWith("a")) count++;
        }
        System.out.println("Q8: Earthquakes <1000km from Denver and ending with 'a': " + count);
    }

    // Question 9: Mag between 3.5–4.5 inclusive, Depth between -55000 and -20000 inclusive
    public void query9() {
        int count = 0;
        for (QuakeEntry qe : quakeList) {
            double mag = qe.getMagnitude();
            double depth = qe.getDepth();
            if (mag >= 3.5 && mag <= 4.5 && depth >= -55000 && depth <= -20000) count++;
        }
        System.out.println("Q9: Mag 3.5–4.5 and Depth -55000 to -20000: " + count);
    }

    // Question 10: Mag 1.0–4.0, Depth -180000 to -30000, title contains 'o'
    public void query10() {
        int count = 0;
        for (QuakeEntry qe : quakeList) {
            double mag = qe.getMagnitude();
            double depth = qe.getDepth();
            if (mag >= 1.0 && mag <= 4.0 && depth >= -180000 && depth <= -30000 &&
                qe.getInfo().toLowerCase().contains("o")) {
                count++;
            }
        }
        System.out.println("Q10: Mag 1–4, Depth -180000 to -30000, title has 'o': " + count);
    }

    // Question 11: Mag 0–5, Distance < 3,000,000 from Billund, title contains 'e'
    public void query11() {
        Location billund = new Location(55.7308, 9.1153);
        int count = 0;
        for (QuakeEntry qe : quakeList) {
            double mag = qe.getMagnitude();
            if (mag >= 0.0 && mag <= 5.0 &&
                qe.getLocation().distanceTo(billund) < 3000000 &&
                qe.getInfo().toLowerCase().contains("e")) {
                count++;
            }
        }
        System.out.println("Q11: Mag 0–5, <3000km from Billund, title has 'e': " + count);
    }

    public static void main(String[] args) {
        EarthQuakeMultiQuery multi = new EarthQuakeMultiQuery();
        multi.runAllQueries();
    }
}
