import java.util.*;
import edu.duke.*;

public class EarthQuakeClient2 {

    // Filters a list of quakes using the given Filter criteria
    public ArrayList<QuakeEntry> filter(ArrayList<QuakeEntry> quakeData, Filter f) {
        ArrayList<QuakeEntry> result = new ArrayList<>();
        for (QuakeEntry qe : quakeData) {
            if (f.satisfies(qe)) {
                result.add(qe);
            }
        }
        return result;
    }

    // Filters quakes less than 10,000,000 meters from Tokyo and whose title ends with "Japan"
    public void quakesWithFilter() {
        EarthQuakeParser parser = new EarthQuakeParser();
        String source = "nov20quakedata.atom";  // Full data file
        ArrayList<QuakeEntry> list = parser.read(source);

        if (list == null) {
            System.out.println("No data read - list is null");
            return;
        }

        System.out.println("Read data for " + list.size() + " quakes");

        Location tokyo = new Location(35.42, 139.43);
        DistanceFilter distFilter = new DistanceFilter(tokyo, 10000000);  // 10 million meters

        ArrayList<QuakeEntry> distFiltered = filter(list, distFilter);

        PhraseFilter phraseFilter = new PhraseFilter("end", "Japan");
        ArrayList<QuakeEntry> finalFiltered = filter(distFiltered, phraseFilter);

        System.out.println("Earthquakes within 10,000 km of Tokyo and ending with 'Japan':");
        for (QuakeEntry qe : finalFiltered) {
            System.out.println(qe);
        }
        System.out.println("Found " + finalFiltered.size() + " earthquakes matching this filter.");
    }

    // Main method to run the program
    public static void main(String[] args) {
        EarthQuakeClient2 client = new EarthQuakeClient2();
        client.quakesWithFilter();
    }
}
