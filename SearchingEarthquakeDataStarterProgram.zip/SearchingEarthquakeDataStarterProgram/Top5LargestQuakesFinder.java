import java.util.*;
import edu.duke.*;

public class Top5LargestQuakesFinder {

    // Finds the index of the quake with the largest magnitude
    private int indexOfLargest(ArrayList<QuakeEntry> quakeData) {
        int maxIndex = 0;
        for (int i = 1; i < quakeData.size(); i++) {
            if (quakeData.get(i).getMagnitude() > quakeData.get(maxIndex).getMagnitude()) {
                maxIndex = i;
            }
        }
        return maxIndex;
    }

    // Returns a list of the n largest magnitude quakes
    public ArrayList<QuakeEntry> findLargestQuakes(ArrayList<QuakeEntry> quakeData, int howMany) {
        ArrayList<QuakeEntry> copy = new ArrayList<>(quakeData);
        ArrayList<QuakeEntry> result = new ArrayList<>();

        for (int i = 0; i < howMany && copy.size() > 0; i++) {
            int maxIndex = indexOfLargest(copy);
            result.add(copy.get(maxIndex));
            copy.remove(maxIndex);
        }

        return result;
    }

    public void testFindTop5Largest() {
        EarthQuakeParser parser = new EarthQuakeParser();
        String source = "nov20quakedata.atom"; // File with 1518 quakes
        ArrayList<QuakeEntry> list = parser.read(source);

        if (list == null || list.isEmpty()) {
            System.out.println("No data read or empty list.");
            return;
        }

        System.out.println("Read data for " + list.size() + " quakes");

        ArrayList<QuakeEntry> largest5 = findLargestQuakes(list, 5);

        System.out.println("Top 5 Earthquakes by Magnitude:");
        for (QuakeEntry qe : largest5) {
            System.out.println(qe);
        }

        if (largest5.size() >= 5) {
            QuakeEntry fifth = largest5.get(4);
            String title = fifth.getInfo();
            String country = extractCountryFromTitle(title);
            System.out.println("\nCountry of the 5th largest earthquake: " + country);
        } else {
            System.out.println("Less than 5 earthquakes found.");
        }
    }

    // Tries to extract the country from the quake's title
    private String extractCountryFromTitle(String title) {
        // Example title format: "123km NW of Someplace, Country"
        if (title.contains(",")) {
            String[] parts = title.split(",");
            return parts[parts.length - 1].trim(); // Return the last part
        }
        return "Unknown";
    }

    public static void main(String[] args) {
        Top5LargestQuakesFinder finder = new Top5LargestQuakesFinder();
        finder.testFindTop5Largest();
    }
}
